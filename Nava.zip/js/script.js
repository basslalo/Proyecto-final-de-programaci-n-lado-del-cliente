
function validacion(){
   	//Numerico
   	var valor=document.getElementById("clap").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("clad").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hcp").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hcd").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hpp").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hpd").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}
	var valor=document.getElementById("creditos").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}
	//Termnina primera columna
	var valor=document.getElementById("clap1").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("clad1").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hcp1").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hcd1").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hpp1").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hpd1").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}
	var valor=document.getElementById("creditos1").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("clap2").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("clad2").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hcp2").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hcd2").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hpp2").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}

	var valor=document.getElementById("hpd2").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}
	var valor=document.getElementById("creditos2").value;
	if (isNaN(valor))
	{alert("Error: un dato no es numerico");}
}
   